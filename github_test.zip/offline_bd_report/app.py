from flask import Flask, request, jsonify
from blackduck.HubRestApi import HubInstance
import json, traceback, os, logging
from functools import wraps

app = Flask(__name__)

CONFIG_FILE = "blackduck_config.json"
USER_FILE = "users.json"
LOG_FILE = "app.log"

# ------------------ Logging Configuration ------------------
logging.basicConfig(
    filename=LOG_FILE,
    level=logging.DEBUG,
    format="%(asctime)s [%(levelname)s] %(message)s",
)
console = logging.StreamHandler()
console.setLevel(logging.DEBUG)
formatter = logging.Formatter("%(asctime)s [%(levelname)s] %(message)s")
console.setFormatter(formatter)
logging.getLogger("").addHandler(console)

logging.info("🚀 Starting Flask Black Duck API Service...")

# ------------------ Utility Functions ------------------

def load_json(file_path):
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        logging.info(f"✅ Loaded JSON config from {file_path}")
        return data
    except Exception as e:
        logging.error(f"❌ Failed to load JSON file: {file_path}, Error: {e}")
        raise

def connect_to_blackduck():
    try:
        config = load_json(CONFIG_FILE)
        hub = HubInstance(
            config["baseurl"],
            api_token=config["api_token"],
            insecure=config.get("insecure", False)
        )
        logging.info(f"✅ Connected to Black Duck server: {config['baseurl']}")
        return hub
    except Exception as e:
        logging.error(f"❌ Black Duck connection failed: {e}\n{traceback.format_exc()}")
        return None

hub = connect_to_blackduck()
if hub is None:
    logging.warning("⚠️ Black Duck initialization failed!")

# ------------------ Authentication ------------------

def load_users():
    if not os.path.exists(USER_FILE):
        logging.warning(f"⚠️ User file {USER_FILE} not found!")
        return {}
    with open(USER_FILE, 'r', encoding='utf-8') as f:
        users = json.load(f)
    logging.info(f"✅ Loaded {len(users)} users from {USER_FILE}")
    return users

def check_auth(username, password):
    users = load_users()
    valid = username in users and users[username] == password
    logging.info(f"🔐 Auth check for user '{username}' => {'✅ Success' if valid else '❌ Failed'}")
    return valid

def require_auth(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        auth = request.authorization
        if not auth or not check_auth(auth.username, auth.password):
            logging.warning("❌ Unauthorized access attempt.")
            return jsonify({"error": "Unauthorized access. Provide valid credentials."}), 401
        return f(*args, **kwargs)
    return decorated

# ------------------ Routes ------------------

@app.route("/health", methods=["GET"])
@require_auth
def health_check():
    logging.info("📡 Health check requested")
    return jsonify({
        "status": "✅ API reachable",
        "blackduck_connection": "Active" if hub else "Failed"
    }), 200

@app.route("/project/<string:project_name>", methods=["GET"])
@require_auth
def get_project_info(project_name):
    logging.info(f"📘 Fetching project info for: {project_name}")
    try:
        project = hub.get_project_by_name(project_name)
        if not project:
            logging.warning(f"❌ Project not found: {project_name}")
            return jsonify({"error": f"Project '{project_name}' not found"}), 404
        logging.info(f"✅ Found project: {project_name}")
        return jsonify(project)
    except Exception as e:
        logging.error(f"❌ Error fetching project info: {e}\n{traceback.format_exc()}")
        return jsonify({"error": str(e), "trace": traceback.format_exc()}), 500

@app.route("/project/<string:project_name>/versions", methods=["GET"])
@require_auth
def get_project_versions(project_name):
    logging.info(f"📗 Fetching versions for project: {project_name}")
    try:
        project = hub.get_project_by_name(project_name)
        if not project:
            return jsonify({"error": f"Project '{project_name}' not found"}), 404
        versions = hub.get_project_versions(project)
        logging.info(f"✅ Found {len(versions.get('items', []))} versions for {project_name}")
        return jsonify(versions)
    except Exception as e:
        logging.error(f"❌ Error fetching project versions: {e}\n{traceback.format_exc()}")
        return jsonify({"error": str(e), "trace": traceback.format_exc()}), 500

@app.route("/project/<string:project_name>/version/<string:version_name>", methods=["GET"])
@require_auth
def get_project_version_info(project_name, version_name):
    logging.info(f"📙 Fetching version info for {project_name} - {version_name}")
    try:
        project = hub.get_project_by_name(project_name)
        if not project:
            return jsonify({"error": f"Project '{project_name}' not found"}), 404

        versions = hub.get_project_versions(project)
        version = next((v for v in versions.get("items", []) if v["versionName"] == version_name), None)
        if not version:
            logging.warning(f"❌ Version not found: {version_name}")
            return jsonify({"error": f"Version '{version_name}' not found"}), 404

        logging.info(f"✅ Found version info for {version_name}")
        return jsonify(version)
    except Exception as e:
        logging.error(f"❌ Error fetching version info: {e}\n{traceback.format_exc()}")
        return jsonify({"error": str(e), "trace": traceback.format_exc()}), 500

@app.route("/project/<string:project_name>/version/<string:version_name>/components", methods=["GET"])
@require_auth
def get_project_version_components(project_name, version_name):
    logging.info(f"📒 Fetching components for {project_name} - {version_name}")
    try:
        project = hub.get_project_by_name(project_name)
        if not project:
            return jsonify({"error": f"Project '{project_name}' not found"}), 404

        versions = hub.get_project_versions(project)
        version = next((v for v in versions.get("items", []) if v["versionName"] == version_name), None)
        if not version:
            return jsonify({"error": f"Version '{version_name}' not found"}), 404

        components = hub.get_version_components(version)
        logging.info(f"✅ Found {len(components.get('items', []))} components in version {version_name}")
        return jsonify(components)
    except Exception as e:
        logging.error(f"❌ Error fetching version components: {e}\n{traceback.format_exc()}")
        return jsonify({"error": str(e), "trace": traceback.format_exc()}), 500

# ------------------ Run Server ------------------
if __name__ == "__main__":
    logging.info("🟢 Starting Flask API on port 5021")
    app.run(host="0.0.0.0", port=5021, debug=True)
